package application.front.controller;


public class AutostradaPageController {

	
}
