package application.front.controller;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;

public class CaselloPageController {

    @FXML
    private TextField newToolboothNameInsert;

    @FXML
    private TextField newKilometroInsert;

    @FXML
    private ChoiceBox<?> selectMotorwayofInsert;

    @FXML
    private Button InsertButtonToolbooth;

    @FXML
    void InsertnewKilometroInsert(MouseEvent event) {

    }

    @FXML
    void SelectMotorwayInsert(MouseEvent event) {

    }

    @FXML
    void writeNewInsertName(MouseEvent event) {

    }

}

