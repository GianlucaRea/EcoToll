package application.front.controller;

import application.controller.ControllerAutostrada;
import application.controller.ControllerCasello;
import application.controller.ControllerVeicolo;


public class GlobalData {
	private static GlobalData instance;
	ControllerAutostrada controllerAutostrada;
	ControllerCasello controllerCasello;
	private ControllerVeicolo controllerVeicolo;
	
	//private casello c;
	private GlobalData() {
		
	}
	
	public static GlobalData get() {
		if (instance == null){
			instance = new GlobalData();
			instance.init();
		}
		return instance;
	}
	
	private void init() {
		controllerAutostrada = ControllerAutostrada.getInstance();
		controllerCasello = ControllerCasello.getInstance();
		controllerVeicolo = new ControllerVeicolo();
	}

	public ControllerAutostrada getControllerAutostrada() {
		return controllerAutostrada;
	}
	
	public ControllerCasello getControllerCasello() {
		return controllerCasello;
	}

	public ControllerVeicolo getControllerVeicolo() {
		return controllerVeicolo;
	}
	

}