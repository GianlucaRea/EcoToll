/*package application.model;

import java.util.HashSet;
import java.util.TreeMap;

public class Prova {

	public static void main(String[] args) {
		
		//il mio Veicolo 
		 Veicolo macchina = new Veicolo("Barchetta", "FR345AY", "FIAT",1400, 2006, 2, 1.22);
		
		// 3 nuovi caselli
		Casello c1 = new Casello("Atina", 300);
		Casello c2 = new Casello("Sora", 317);
		Casello c5 = new Casello("Non usato", 340);
		
		//3 nuovi caselli
		Casello c3 = new Casello("prova 1", 257);
		Casello c4 = new Casello("prova 2", 223);
		Casello c6 = new Casello("Non usato", 260);
		
		//TreeMap delle tariffe per ogni veicolo di classi da 1 a 5
		TreeMap<Integer, Double> tariffe1 = new TreeMap<Integer, Double>();
		TreeMap<Integer, Double> tariffe2 = new TreeMap<Integer, Double>();
		//Racchiudo i caselli che voglio passare all' autostrada A14  in un hashSet (che passer� come parametro)
		HashSet<Casello> listaA14 = new HashSet<Casello>();
		listaA14.add(c1);
		listaA14.add(c2);
		listaA14.add(c5);
		//Assegno tariffe e caselli alle relative autostrade (alla seconda la faccio aggiungendone uno alla volta)
		Autostrada autostrada1 = new Autostrada("A14", tariffe1, listaA14);
		Autostrada autostrada2 = new Autostrada("A55",tariffe2);
		autostrada2.addCasello(c3);
		autostrada2.addCasello(c4);
		autostrada2.addCasello(c6);
		autostrada1.setTariffa(1, 1.0);
		autostrada1.setTariffa(2, 2.0);
		autostrada1.setTariffa(3, 3.0);
		autostrada1.setTariffa(4, 4.0);
		autostrada1.setTariffa(5, 5.0);
		autostrada2.setTariffa(1, 1.5);
		autostrada2.setTariffa(2, 2.5);
		autostrada2.setTariffa(3, 3.5);
		autostrada2.setTariffa(4, 4.5);
		autostrada2.setTariffa(5, 5.5);
		
		//Genero i miei percorsi sulle relative autostrade (supponiamo che tali percorsi ci siano dati da input dai biglietti)
		Percorso p1 = new Percorso(c1,c2, autostrada1);
		Percorso p2 = new Percorso(c3,c4, autostrada2);
		
		//Stampo il pedaggio da pagare su tali percorsi utilizzando macchina come veicolo
		System.out.print(Pedaggio.calcolaPedaggio(macchina, p1));
		System.out.println(" ");
		System.out.print(Pedaggio.calcolaPedaggio(macchina, p2));
		
	}

}
 */


