		package application.front.controller;

import java.util.ArrayList;

import application.controller.ControllerAutostrada;
import application.controller.ControllerCasello;
import application.controller.ControllerVeicolo;
import application.model.Casello;


public class GlobalData {
	private static GlobalData instance;
	ControllerAutostrada controllerAutostrada;
	ControllerCasello controllerCasello;
	private ControllerVeicolo controllerVeicolo;
	
	ArrayList<Casello> caselli;   //novit�
	
	//private casello c;
	private GlobalData() {
		
	}
	
	public static GlobalData get() {
		if (instance == null){
			instance = new GlobalData();
			instance.init();
		}
		return instance;
	}
	
	private void init() {
		controllerAutostrada = ControllerAutostrada.getInstance();
		controllerCasello = ControllerCasello.getInstance();
		controllerVeicolo = new ControllerVeicolo();
		
		caselli = new ArrayList<>();
		for (Casello c: getControllerCasello().getAllCas()) {
    		caselli.add(c);
    	}
	}

	public ControllerAutostrada getControllerAutostrada() {
		return controllerAutostrada;
	}
	
	public ControllerCasello getControllerCasello() {
		return controllerCasello;
	}

	public ControllerVeicolo getControllerVeicolo() {
		return controllerVeicolo;
	}
	

}